package com.example.SBNZApp.facts;


public enum Karakteristike {
	Sunce,
	Hlad,
	Voda,
	OdmorBezAktivnosti,
	OdmorSaAktivnostima,
	Urbano,
	Mir,
	DugPut,
	KratakPut,
	SvezVazduh,
	IndividualniObilazak,
	GrupniObilazak,
	MedicinskiNadzor,
	KulturniSadrzaj	
}
