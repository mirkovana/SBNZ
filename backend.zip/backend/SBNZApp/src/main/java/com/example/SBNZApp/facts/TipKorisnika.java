package com.example.SBNZApp.facts;

public enum TipKorisnika {
	NEAKTIVNI, PREMIUM
}
