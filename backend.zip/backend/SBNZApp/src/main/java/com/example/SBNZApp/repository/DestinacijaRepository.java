package com.example.SBNZApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SBNZApp.facts.Destinacija;

public interface DestinacijaRepository extends JpaRepository<Destinacija, Long>{

}
