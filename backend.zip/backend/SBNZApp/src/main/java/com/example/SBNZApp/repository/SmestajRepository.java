package com.example.SBNZApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SBNZApp.facts.Smestaj;

public interface SmestajRepository extends JpaRepository<Smestaj, Long>{

}
